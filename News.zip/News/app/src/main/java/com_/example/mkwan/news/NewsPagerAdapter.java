package com_.example.mkwan.news;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class NewsPagerAdapter extends FragmentPagerAdapter {
    ArrayList<Fragment> fragmentsArrayList;
    String[] listOfFragment;

    public NewsPagerAdapter(FragmentManager fm, ArrayList<Fragment> fragmentsArrayList, String[] listOfFragment) {
        super(fm);
        this.fragmentsArrayList = fragmentsArrayList;
        this.listOfFragment = listOfFragment;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return listOfFragment[position];
    }


    @Override
    public Fragment getItem(int position) {
        return fragmentsArrayList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentsArrayList.size();
    }
}
