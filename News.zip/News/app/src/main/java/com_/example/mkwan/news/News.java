package com_.example.mkwan.news;

public class News {
    private String image;
    private String title;
    private String sectionName;
    private String authorName;
    private String publishedDate;
    private String websiteURL;

    public News(String image, String title, String sectionName, String authorName, String publishedDate, String websiteURL) {
        this.image = image;
        this.title = title;
        this.sectionName = sectionName;
        this.authorName = authorName;
        this.publishedDate = publishedDate;
        this.websiteURL = websiteURL;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getPublishedDate() {
        return publishedDate;
    }

    public String getWebsiteURL() {
        return websiteURL;
    }
}
