package com_.example.mkwan.news;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ViewPager newsViewPager;
    TabLayout newsTabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newsViewPager = findViewById(R.id.news_view_pager);
        newsTabLayout = findViewById(R.id.news_tab_layout);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.action_bar_style);

        String[] listOfFragments = {getString(R.string.top_story), getString(R.string.sport)};
        ArrayList<Fragment> fragmentsArrayList = new ArrayList<>();
        fragmentsArrayList.add(new TopStoryFragment());
        fragmentsArrayList.add(new SportFragment());
        NewsPagerAdapter fragmentsAdapter = new NewsPagerAdapter(getSupportFragmentManager(), fragmentsArrayList, listOfFragments);
        newsViewPager.setAdapter(fragmentsAdapter);
        newsTabLayout.setupWithViewPager(newsViewPager);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.setting_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.section_name:
                Intent sectionIntent = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(sectionIntent);
                break;
            case R.id.contact_us:
                Intent implicit = new Intent(Intent.ACTION_SENDTO);
                implicit.setData(Uri.parse(getString(R.string.mail_to)));
                implicit.putExtra(Intent.EXTRA_EMAIL, getString(R.string.bbc_email));
                implicit.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.fedback));
                implicit.putExtra(Intent.EXTRA_TEXT, getString(R.string.email_text));
                if (implicit.resolveActivity(getPackageManager()) != null) {
                    startActivity(implicit);
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
