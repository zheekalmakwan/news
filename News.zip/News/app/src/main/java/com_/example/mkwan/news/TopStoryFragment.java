package com_.example.mkwan.news;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

public class TopStoryFragment extends Fragment implements LoaderManager.LoaderCallbacks<ArrayList<News>> {

    View topStoryView;
    GridView topStoryListView;
    private TextView noNetowrkTextView;
    private TextView emptyListTextView;


    public static String url_string = "https://content.guardianapis.com/search?api-key=2173e8ef-807c-4357-b7ba-e33844184676&show-fields=byline,thumbnail";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        topStoryView = inflater.inflate(R.layout.top_story_fragment, container, false);
        noNetowrkTextView = topStoryView.findViewById(R.id.network_top_story_data_tv);
        topStoryListView = topStoryView.findViewById(R.id.top_story_news_lv);
        ConnectivityManager connectivityManager =
                (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if (isConnected) {
            getActivity().getSupportLoaderManager().initLoader(1, null, this).forceLoad();
        } else {
            topStoryListView.setVisibility(View.GONE);
            noNetowrkTextView.setVisibility(View.VISIBLE);
            noNetowrkTextView.setText(R.string.no_network);
        }
        return topStoryView;
    }


    @Override
    public Loader<ArrayList<News>> onCreateLoader(int id, Bundle args) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String section = sharedPreferences.getString(getString(R.string.section_name_key), getContext().getString(R.string.app_name));
        Uri uriBase = Uri.parse(url_string);
        Uri.Builder builder = uriBase.buildUpon();
        builder.appendQueryParameter(getContext().getString(R.string.q), section);
        builder.build();
        return new NewsAsyncTaskLoader(getActivity(), builder.toString());
    }


    @Override
    public void onLoadFinished(Loader<ArrayList<News>> loader, ArrayList<News> data) {
        emptyListTextView = topStoryView.findViewById(R.id.empty_top_story_data_tv);
        if (data.isEmpty()) {
            topStoryListView.setVisibility(View.GONE);
            noNetowrkTextView.setVisibility(View.GONE);
            emptyListTextView.setVisibility(View.VISIBLE);
            emptyListTextView.setText(R.string.empty_list);

        } else {
            final NewsAdapter topStoryAdapter = new NewsAdapter(getActivity(), R.layout.list_view_style, data);
            topStoryListView.setAdapter(topStoryAdapter);
            topStoryListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    News currentArticle = (News) adapterView.getItemAtPosition(i);
                    Uri newsArticle = Uri.parse(currentArticle.getWebsiteURL());
                    Intent websiteIntent = new Intent(Intent.ACTION_VIEW, newsArticle);
                    startActivity(websiteIntent);
                }
            });

        }
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<News>> loader) {

    }

    @Override
    public void onStart() {
        super.onStart();
        LoaderManager loaderManager = getActivity().getSupportLoaderManager();
        Loader loader = loaderManager.getLoader(0);
        if (loader == null) {
            loaderManager.initLoader(1, null, TopStoryFragment.this).forceLoad();
        } else {
            loaderManager.restartLoader(1, null, TopStoryFragment.this).forceLoad();
        }
    }
}
