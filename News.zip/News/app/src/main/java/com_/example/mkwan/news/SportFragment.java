package com_.example.mkwan.news;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

import com_.example.mkwan.news.News;
import com_.example.mkwan.news.NewsAdapter;
import com_.example.mkwan.news.NewsAsyncTaskLoader;
import com_.example.mkwan.news.R;

public class SportFragment extends Fragment implements LoaderManager.LoaderCallbacks<ArrayList<News>> {
    View sportView;
    GridView sportListView;
    private TextView noNetworkTextViewSport;
    private TextView emptyListTextView;
    public static String url_string = "https://content.guardianapis.com/search?api-key=2173e8ef-807c-4357-b7ba-e33844184676&show-fields=byline,thumbnail&q=Sport";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        sportView = inflater.inflate(R.layout.sport_fragment, container, false);

        sportListView = sportView.findViewById(R.id.sport_news_lv);

        ConnectivityManager connectivityManager =
                (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if (isConnected) {
            getActivity().getSupportLoaderManager().initLoader(0, null, this).forceLoad();
        } else {
            sportListView.setVisibility(View.GONE);
            noNetworkTextViewSport = sportView.findViewById(R.id.network_sport_data_tv);
            noNetworkTextViewSport.setVisibility(View.VISIBLE);
            noNetworkTextViewSport.setText(R.string.no_network);

        }
        return sportView;
    }

    @Override
    public Loader<ArrayList<News>> onCreateLoader(int id, Bundle args) {


        return new NewsAsyncTaskLoader(getActivity(), url_string);
    }


    @Override
    public void onLoadFinished(Loader<ArrayList<News>> loader, ArrayList<News> data) {

        emptyListTextView = sportView.findViewById(R.id.empty_sport_data_tv);
        if (data.isEmpty()) {
            sportListView.setVisibility(View.GONE);
            noNetworkTextViewSport.setVisibility(View.GONE);
            emptyListTextView.setVisibility(View.VISIBLE);
            emptyListTextView.setText(R.string.empty_list);
        } else {
            NewsAdapter sportAdapter = new NewsAdapter(getActivity(), R.layout.list_view_style, data);
            sportListView.setAdapter(sportAdapter);

            sportListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    News currentArticle = (News) adapterView.getItemAtPosition(i);
                    Uri newsArticle = Uri.parse(currentArticle.getWebsiteURL());
                    Intent websiteIntent = new Intent(Intent.ACTION_VIEW, newsArticle);
                    startActivity(websiteIntent);
                }
            });
        }

    }

    @Override
    public void onLoaderReset(Loader<ArrayList<News>> loader) {

    }

}
