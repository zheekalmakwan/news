package com_.example.mkwan.news;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class NewsAsyncTaskLoader extends AsyncTaskLoader<ArrayList<News>> {

    private String url_string;

    public NewsAsyncTaskLoader(Context context, String url_string) {
        super(context);
        this.url_string = url_string;
    }

    @Override
    public ArrayList<News> loadInBackground() {

        ArrayList<News> newsArrayList = new ArrayList<>();
        try {

            URL newsUrl = new URL(url_string);
            HttpURLConnection newsHttpURLConnection = (HttpURLConnection) newsUrl.openConnection();
            newsHttpURLConnection.setRequestMethod(getContext().getString(R.string.get));
            newsHttpURLConnection.setConnectTimeout(10000);
            newsHttpURLConnection.setReadTimeout(15000);
            newsHttpURLConnection.connect();
            InputStream newsInputStream = newsHttpURLConnection.getInputStream();
            InputStreamReader newsInputStreamReader = new InputStreamReader(newsInputStream);
            BufferedReader newsBufferReader = new BufferedReader(newsInputStreamReader);
            String lineOfData = newsBufferReader.readLine();
            StringBuilder JSONData = new StringBuilder();
            while (lineOfData != null) {
                JSONData.append(lineOfData);
                lineOfData = newsBufferReader.readLine();
            }

            String image = "";
            String title = "";
            String sectionName = "";
            String authorName = "";
            String publishedDate = "";
            String websiteURL = "";
            JSONObject root = new JSONObject(JSONData.toString());
            if (root.has(getContext().getString(R.string.response))) {
                JSONObject responseObject = root.getJSONObject(getContext().getString(R.string.response));
                if (responseObject.has(getContext().getString(R.string.results))) {
                    JSONArray newsJSONArray = responseObject.getJSONArray(getContext().getString(R.string.results));
                    for (int i = 0; i < newsJSONArray.length(); i++) {
                        JSONObject elements = newsJSONArray.getJSONObject(i);
                        JSONObject fieldsObject = elements.getJSONObject(getContext().getString(R.string.fields));
                        if (fieldsObject.has(getContext().getString(R.string.thumbnail))) {
                            image = fieldsObject.getString(getContext().getString(R.string.thumbnail));
                        }
                        if (elements.has(getContext().getString(R.string.webTitle))) {
                            title = elements.getString(getContext().getString(R.string.webTitle));
                        }
                        if (elements.has(getContext().getString(R.string.pillarName))) {
                            sectionName = elements.getString(getContext().getString(R.string.pillarName));
                        }
                        if (fieldsObject.has(getContext().getString(R.string.byline))) {
                            authorName = fieldsObject.getString(getContext().getString(R.string.byline));
                        }
                        if (elements.has(getContext().getString(R.string.webPublicationDate))) {
                            publishedDate = elements.getString(getContext().getString(R.string.webPublicationDate));
                        }
                        if (elements.has(getContext().getString(R.string.webUrl))) {
                            websiteURL = elements.getString(getContext().getString(R.string.webUrl));
                        }

                        newsArrayList.add(new News(image, title, sectionName, authorName, publishedDate, websiteURL));

                    }
                }
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return newsArrayList;
    }
}
