package com_.example.mkwan.news;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News> {

private Context context;
private int resource;
        ArrayList<News> objects;

public NewsAdapter(@NonNull Context context, int resource, @NonNull ArrayList<News> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        }

@NonNull
@Override
public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        NewsViewHolder newsViewHolderObject;
        if (convertView == null) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        convertView = layoutInflater.inflate(resource, null);
        newsViewHolderObject = new NewsViewHolder();
        newsViewHolderObject.newsImage = convertView.findViewById(R.id.news_image);
        newsViewHolderObject.title = convertView.findViewById(R.id.title);
        newsViewHolderObject.sectionName = convertView.findViewById(R.id.section_name);
        newsViewHolderObject.authorName = convertView.findViewById(R.id.author_name);
        newsViewHolderObject.publishedDate = convertView.findViewById(R.id.published_date);
        newsViewHolderObject.websiteURL = convertView.findViewById(R.id.website_url);
        convertView.setTag(newsViewHolderObject);
        } else {
        newsViewHolderObject = (NewsViewHolder) convertView.getTag();

        }
        News newsObject = objects.get(position);
        if (newsObject.getImage() != null) {
        Picasso.get().load(newsObject.getImage()).into(newsViewHolderObject.newsImage);
        }
        if (newsObject.getTitle() != null) {
        newsViewHolderObject.title.setText(newsObject.getTitle());
        }
        if (newsObject.getSectionName() != null) {
        newsViewHolderObject.sectionName.setText(newsObject.getSectionName());
        }
        if (newsObject.getAuthorName() != null) {
        newsViewHolderObject.authorName.setText(newsObject.getAuthorName());
        }
        if (newsObject.getPublishedDate() != null) {
        newsViewHolderObject.publishedDate.setText(newsObject.getPublishedDate());
        }
        if (newsObject.getWebsiteURL() != null) {
        newsViewHolderObject.websiteURL.setText(newsObject.getWebsiteURL());
        }
        return convertView;
        }
        }

class NewsViewHolder {
    ImageView newsImage;
    TextView title;
    TextView sectionName;
    TextView authorName;
    TextView publishedDate;
    TextView websiteURL;
}
